<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tags</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data" action="<?= base_url('webadmsekolah/jurusan/simpan')?>">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Nama Jurusan</label>
                  <input type="text" class="form-control" id="" placeholder="Enter email" required  name="panjang" >
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Nama Pendek Jurusan Tampil</label>
                  <input type="text" class="form-control" id="" placeholder="Enter email" required  name="pendek" >
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Logo Jurusan</label>
                  <input type="file" id="exampleInputFile" required=""  value="" name="gambar" >

                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Keterangan Prodi</label>
                  <textarea name="keterangan" class="ckeditor" required="" id="text-ckeditor"></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1"> Kompetensi / Materi Yang Diajarkan</label>
                  <textarea name="kompetensi" class="ckeditor" required="" id="text-ckeditor"></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1"> Profesi / Bidang Kerja</label>
                  <textarea name="profesi" class="ckeditor" required="" id="text-ckeditor"></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1"> Prestasi</label>
                  <textarea name="prestasi" class="ckeditor" required="" id="text-ckeditor"></textarea>
                </div>
              <!-- /.box-body -->
            </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Simmpan</button>
                 <a href="../../profilsekolah"><button type="button" class="btn btn-danger">Kembali</button></a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
