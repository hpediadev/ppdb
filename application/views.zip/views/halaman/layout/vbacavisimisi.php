<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
                            <div id="tg-content" class="tg-content">
                                
                                
                                <section class="tg-sectionspace tg-haslayout">
                                    <div class="tg-latestnews">
                        <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Visi Misi dan Tujuan</h2>
                                        </div>
											<!---- ======START BERITA==== ---->
                                            <?php
                                                foreach ($dataartikel as $row) {    
                                            ?>
										<article class="tg-themepost tg-newspost">
										
										<div class="tg-themepostcontent">
										<div class="tg-description">
											<?= $row->VISIMISI ?> 
										</div>
									</article>

									
									<?PHP } ?>
                                            	<!---- ======END BERITA==== ---->
									<div class="tg-tagsandpsotshares">
										<div class="tg-tagstext">
											<span>tags:</span>
											<div class="tg-tags">
												<a class="tg-tag" href="javascript:void(0);">Student</a>
												<a class="tg-tag" href="javascript:void(0);">Examination</a>
												<a class="tg-tag" href="javascript:void(0);">Easy Learning</a>
												<a class="tg-tag" href="javascript:void(0);">Pencils</a>
												<a class="tg-tag" href="javascript:void(0);">Technology</a>
												<a class="tg-tag" href="javascript:void(0);">Video</a>
												<a class="tg-tag" href="javascript:void(0);">Teachers</a>
												<a class="tg-tag" href="javascript:void(0);">Amazing Trips</a>
												<a class="tg-tag" href="javascript:void(0);">News</a>
												<a class="tg-tag" href="javascript:void(0);">Bully Kids</a>
											</div>
										</div>
										<div class="tg-sharetext">
											<span>share:</span>
											<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
												<li class="tg-skype"><a href="javascript:void(0);"><i class="fa fa-skype"></i></a></li>
												<li class="tg-dropbox"><a href="javascript:void(0);"><i class="fa fa-dropbox"></i></a></li>
												<li class="tg-vimeo"><a href="javascript:void(0);"><i class="fa fa-vimeo"></i></a></li>
												<li class="tg-stumbleupon"><a href="javascript:void(0);"><i class="fa fa-stumbleupon"></i></a></li>
												<li class="tg-yahoo"><a href="javascript:void(0);"><i class="fa fa-yahoo"></i></a></li>
												<li class="tg-pinterestp"><a href="javascript:void(0);"><i class="fa fa-pinterest"></i></a></li>
												<li class="tg-youtube"><a href="javascript:void(0);"><i class="fa fa-youtube"></i></a></li>
											</ul>
										</div>
									</div>
									<!-- <div class="tg-postauthor">
										<figure><a href="javascript:void(0);"><img src="images/img-18.jpg" alt="image description"></a></figure>
										<div class="tg-postauthorcontent">
											<div class="tg-postauthorhead">
												<h4><a href="javascript:void(0);">Maragaret Ellinger</a></h4>
												<span>Author Since: June 27, 2015</span>
												<ul class="tg-socialicons">
													<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
													<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
													<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
													<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
													<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
												</ul>
											</div>
											<div class="tg-description">
												<p>Consequat duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat nullataka pariatur occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum perspiciatis undes omnis iste natus error sit quae ab illo inventore irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat ananulla pariatur occaecat cupidatat non dolore eu fugiat nullataka pariatur.</p>
											</div>
										</div>
									</div> -->
									
                                </section>

                                
                            </div>
                        </div>