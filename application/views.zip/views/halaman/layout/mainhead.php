<div class="tg-tickerbox">
            <div class="container">
                <div class="row ">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">  
                    <p><marquee style="color: red;font-weight: bold;" > Selamat Datang Di Situs Resmi SMK Putra Bangsa Waru Barat Waru Pamekasan</marquee></p>
                                
                        <!-- <div id="tg-ticker" class="tg-ticker owl-carousel ">
                                <p><marquee style="color: red;font-weight: bold;" > Selamat Datang Di Situs Resmi SMK Putra Bangsa Waru Barat Waru Pamekasan</marquee></p>
                                
                            <div class="item ">
                                <div class="tg-description">
                                    <p><marquee style="color: red;font-weight: bold;" > Selamat Datang Di Situs Resmi SMK Putra Bangsa Waru Barat Waru Pamekasan</marquee></p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="tg-description">
                                    <p>Consectetur adipisicing elit sed do eiusmod qua enim ad minim veniam, quis nostrud exercitation.</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="tg-description">
                                    <p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim.</p>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                Home Slider End
        *************************************-->
        <!--************************************
                Main Start
        *************************************-->
        

        
       
        <main id="tg-main" class="tg-main tg-haslayout">
            <div class="container">
                <div class="row">
                    <div id="tg-twocolumns" class="tg-twocolumns">
                        <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <section class="tg-sectionspace tg-haslayout">
                                <div class="tg-shortcode tg-welcomeandgreeting tg-welcomeandgreeting-v2">
                                    <figure><img src="<?= base_url('assets/images/img-03.jpg')?>" alt="image description"></figure>
                                    <div class="tg-shortcodetextbox">
                                        <h2>Welcome &amp; Greetings!</h2>
                                        <div class="tg-description">
                                            <p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore et dolore amit agna aliqua enimnate minim veniam quis nostrud exercitation ullamco laboris nisi utiata ...</p>
                                        </div>
                                        <span class="tg-name">Prof. Donovan Bradburn</span>
                                        <span class="tg-designation">Vice Chancellor</span>
                                        <div class="tg-btnpluslogo">
                                            <a class="tg-btn" href="javascript:void(0);">read more</a>
                                            <strong class="tg-universitylogo"><a href="javascript:void(0);"><img src="<?= base_url('assets/images/logo2.png')?>" alt="image description"></a></strong>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div> -->
                        
                       