
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <section class="tg-sectionspace tg-haslayout">
                            <div class="tg-shortcode tg-welcomeandgreeting tg-welcomeandgreeting-v2">
                                <figure><img src="<?= base_url('assets/images/img-03.jpg')?>"alt="image description"></figure>
                                    <div class="tg-shortcodetextbox">
                                        <h2>Sambutan Kepala Sekolah &amp; Greetings!</h2>
                                        <div class="tg-description">
                                            <?= $_SERVER['SERVER_NAME']?>
                                            <p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore et dolore amit agna aliqua enimnate minim veniam quis nostrud exercitation ullamco laboris nisi utiata ...</p>
                                        </div>
                                        <span class="tg-name">Prof. Donovan Bradburn</span>
                                        <span class="tg-designation">Vice Chancellor</span>
                                        <div class="tg-btnpluslogo">
                                            <a class="tg-btn" href="javascript:void(0);">read more</a>
                                            <!-- <strong class="tg-universitylogo"><a href="javascript:void(0);">
                                                <img src="<?= base_url('assets/images/lg.png')?>" alt="image description"></a></strong> -->
                                        </div>
                                    </div>
                            </div>
                        </section>
                    </div>