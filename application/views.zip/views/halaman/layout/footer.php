<!--************************************
                Footer Start
        *************************************-->
        

        <footer id="tg-footer" class="tg-footer tg-haslayout">
            <div class="tg-signupbox" id="warna1">
                <!-- <div class="container">
                    <div class="tg-signuptextbox">
                        <h3>Free Signup!</h3>
                        <div class="tg-description"><p>Subscribe Monthly Newsletter &amp; Get Latest New &amp; Updates.</p></div>
                    </div>
                    <form class="tg-formtheme tg-formsignupfree">
                        <fieldset>
                            <div class="form-group"><input type="text" name="emailid" class="form-control" placeholder="Enter Email ID"></div>
                            <div class="form-group"><button type="submit" class="tg-btn">Signup Now</button></div>
                        </fieldset>
                    </form>
                </div> -->
            </div>
            <div class="tg-footerbar" id="warna2">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <span class="tg-copyright"><a style="color:#fff" target="_blank" href="https://www.mediadigitalofficial.com">
                            &copy; Copyright 2020  MA Al-Hasanah
                            <?//=$u->NAMALEMBAGA?>. 
                            All rights reserved 

                        </a></span>
                            <nav class="tg-addnav">
                            Powered by <a target="_blank"  href="https://www.mediadigitalofficial.com" style="color:#fff">Media Digital</a>
                                <!-- <ul>
                                    <li><a style="color:#fff">Powered by  Media Digital</a></li>
                                    <li><a style="color:#fff">Term and Conditions</a></li>
                                    <li><a style="color:#fff">Contact</a></li>
                                </ul> -->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--************************************
                Footer End
        *************************************-->
    </div>
    <!--************************************
            Wrapper End
    *************************************-->
    <script src="<?= base_url('assets/js/vendor/jquery-library.js')?>"></script>
    <script src="<?= base_url('assets/js/vendor/bootstrap.min.js')?>"></script>
    <script src="<?= base_url('assets/js/mapclustering/data.js')?>on"></script>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyCR-KEWAVCn52mSdeVeTqZjtqbmVJyfSus&amp;language=en"></script>
    <script src="<?= base_url('assets/js/mapclustering/markerclusterer.min.js')?>"></script>
    <script src="<?= base_url('assets/js/mapclustering/infobox.js')?>"></script>
    <script src="<?= base_url('assets/js/mapclustering/map.js')?>"></script>
    <script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script>
    <script src="<?= base_url('assets/js/isotope.pkgd.js')?>"></script>
    <script src="<?= base_url('assets/js/prettyPhoto.js')?>"></script>
    <script src="<?= base_url('assets/js/countdown.js')?>"></script>
    <script src="<?= base_url('assets/js/collapse.js')?>"></script>
    <script src="<?= base_url('assets/js/moment.js')?>"></script>
    <script src="<?= base_url('assets/js/gmap3.js')?>"></script>
    <script src="<?= base_url('assets/js/main.js')?>"></script>
    <script src="<?= base_url('assets/js/share.js')?>"></script>
</body>


</html>