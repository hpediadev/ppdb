
                    
  <div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
                            <div id="tg-content" class="tg-content">
                                <section class="tg-sectionspace tg-haslayout">
                                     <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Berita</h2>
                                    </div>
                                    <!-- <div class="tg-borderheading">
                                        <h2>Latest Events</h2>
                                    </div> -->
                                    <div class="tg-events">
                                        <div class="row">
                                            <?php
                                           // $no = $this->uri->segment('3') + 1;
                                                foreach ($user as $row) {
                                                    # code...
                                                   $jdl = str_replace(" ","-",$row->JUDUL);
                                                   $tanggal = substr($row->TANGGALARTIKEL, 0,10);
                                                     $hari   = date('N', strtotime($tanggal)); 
                                                     $day = array('','Senin','Selasa', 'Rabu','Kamis','Jumat','Sabtu');
                                                     $bln = array('','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
                                                     $tgl   = date('d ', strtotime($tanggal)).$bln[date('n', strtotime($tanggal))].date(' Y ', strtotime($tanggal)); 
                                                     //echo "Tanggal $tanggal adalah hari " . $hari;
                                                     // Tanggal 2017-01-31 adalah hari Tuesday
                                                
                                            ?>
                                            <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
                                                <article class="tg-themepost tg-eventpost">
                                                    <figure class="tg-featuredimg">
                                                        <!-- <a href="javascript:void(0);">
                                                            <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR)?>" alt="image description" alt="image description">
                                                        </a> -->
                                                        <a href="javascript:void(0);" style="width: 100%; height: 150px; overflow: hidden;position: relative;">
                                                            <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR)?>" alt="image description">
                                                        </a>
                                                    </figure>
                                                    <div class="tg-themepostcontent">
                                                        <ul class="tg-matadata">
                                                            <li>
                                                                <a href="javascript:void(0);">
                                                                    <i class="fa fa-calendar"></i>
                                                                    <span><?= $day[$hari].','.$tgl ?></span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                        <div class="tg-themeposttitle">
                                                            <h3><a href="<?=  base_url()?>berita/read/<?= $row->IDARTIKEL.'/'.$jdl.'.html'; ?>"><?= $row->JUDUL." ".strlen($row->JUDUL) ?></a></h3>
                                                        </div>
                                                        <div class="tg-description">
                                                            <p><?= substr($row->SUB,0,50) ?>... <a href="<?=  base_url()?>berita/read/<?= $row->IDARTIKEL.'/'.$jdl.'.html'; ?>">Baca Selanjutnya</a></p>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        <?php } ?>
                                            
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 center">
                                                <center class="tg-themepost tg-eventpost">
                                                    <?php echo $this->pagination->create_links(); ?>
                                                </center>
                                            </div>
                                    </div>
                                </section>
                                
                                
                            </div>
                        </div>