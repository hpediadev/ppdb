<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
							<aside id="tg-sidebar" class="tg-sidebar">
								<div class="tg-widget">
                                    <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Info Terbaru</h2>
                                    </div>
									<div class="tg-widgetcontent">
										<form class="tg-formtheme tg-formsearch">
											<fieldset>
												<input type="search" name="search" class="form-control" placeholder="Start Your Search Here">
												<button type="submit" class="tg-btnsearch"><i class="icon-magnifier"></i></button>
											</fieldset>
										</form>
									</div>
								</div>
								<div class="tg-widget tg-widgetnoticeboard">
                                    <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Berita Populer</h2>
                                    </div>
									<div class="tg-widgetcontent">
										<?php
                                        foreach ($artikelacak as $slidebar) {
                                        	$jdl = str_replace(" ","-",$slidebar->JUDUL);
                                        	 $tanggal = substr($slidebar->TANGGALARTIKEL, 0,10);
                                    $hari   = date('N', strtotime($tanggal)); 
                                    $day = array('','Senin','Selasa', 'Rabu','Kamis','Jumat','Sabtu');
                                    $bln = array('','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
                                    $tgl   = date('d ', strtotime($tanggal)).$bln[date('n', strtotime($tanggal))].date(' Y ', strtotime($tanggal)); 
                                            # code...

                                        
                                        ?>
                                        <article class="tg-campus tg-campusleftthumb">
                                            <figure class="tg-featuredimg">
                                                <a href="" style="width: 60px; height: 60px; overflow: hidden;position: relative;">
                                                    <img style="position: absolute;left: 0px;top: 0px;width: 100%;height: 100%" src="<?= base_url('uploads/artikel/'.$slidebar->GAMBAR)?>" alt="ihmage descrhiption">
                                                </a>
                                            </figure>
                                            <div class="tg-campuscontent">
                                                <ul class="tg-matadata">
                                                    <li>
                                                        <a href="">
                                                            <i class="fa fa-calendar"></i>
                                                            <span><?= $day[$hari].','.$tgl ?></span>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div class="tg-campustitle">
                                                    <h3><a href="<?=  base_url()?>berita/read/<?= $slidebar->IDARTIKEL.'/'.$jdl.'.html'; ?>"><?= $slidebar->JUDUL?></a></h3>
                                                </div>
                                            </div>
                                        </article>
                                    <?php } ?>
                                    <!-- <ul>
											<li>
												<a href="">Adipisicing elit sed dotas eiusmod tempor incididunt utae labore etiat dolore magna aliqua enim ad minim veniam.</a>
											</li>
											<li>
												<a href="">Labore etiat dolore magna aliqua enim ad minim veniam.</a>
											</li>
											<li>
												<a href="">Duis aute irure dolor in reprehenderit.</a>
											</li>
										</ul> -->
									</div>
								</div>
										<?php
										$sql = $this->db->order_by('IDARTIKEL','DESC');
										$sql = $this->db->limit(1);
										$sql =	$this->db->get_where('tartikel_md',array('KATEGORI'=>'informasi'))->result();
										foreach ($sql as $s) {
											# code...

                                $jdl = str_replace(" ","-",$s->JUDUL);
										
										?>
								<div class="tg-widget tg-widgetadmissionform">
									<div class="tg-widgetcontent">
										<h3>Informasi Utama</h3>
										<div class="tg-description">
											<p><?= $s->JUDUL?></p>
										</div>
										<a class="tg-btn tg-btnicon" href="<?=  base_url()?>berita/read/<?= $s->IDARTIKEL.'/'.$jdl.'.html'; ?>">
											<span>Selanjutnya...</span>
										</a>
									</div>
								</div>

									<?php } ?>
									
                                <div class="tg-widget tg-widgetadmissionform">
                                    <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Facebook</h2>
                                    </div>
                                    
                                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fweb.facebook.com%2FPedidikan-Islam-Berbasis-Ict-Ma-Al-Hasanah-539933729692381&tabs=timeline&width=340&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                                </div>
								
							</aside>
						</div>