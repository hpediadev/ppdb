
                        <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
                            <aside id="tg-sidebar" class="tg-sidebar">
                                    
                                <div class="tg-widget tg-widgetadmissionform">
                                    <div class="tg-borderheading sidebar">
									<!-- <div class="split"></div>
                                        <h2>&nbsp;Link</h2>
                                    </div>
                                     -->
                                            <?php
                                        $sql = $this->db->order_by('IDARTIKEL','DESC');
                                        $sql = $this->db->limit(1);
                                        $sql =  $this->db->get_where('tartikel_md',array('KATEGORI'=>'informasi'))->result();
                                        foreach ($sql as $s) {
                                            # code...

                                $jdl = str_replace(" ","-",$s->JUDUL);
                                        
                                        ?>
                                <div class="tg-widget tg-widgetadmissionform">
                                    <div class="tg-widgetcontent">
                                        <h3>Informasi Utama</h3>
                                        <div class="tg-description">
                                            <p><?= $s->JUDUL?></p>
                                        </div>
                                        <a class="tg-btn tg-btnicon" href="<?=  base_url()?>berita/read/<?= $s->IDARTIKEL.'/'.$jdl.'.html'; ?>">
                                            <span>Selanjutnya...</span>
                                        </a>
                                    </div>
                                </div>

                                    <?php } ?>
                                </div>
                                <div class="tg-widget tg-widgetadmissionform">
                                    <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Facebook</h2>
                                    </div>
                                    
                                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fweb.facebook.com%2FPedidikan-Islam-Berbasis-Ict-Ma-Al-Hasanah-539933729692381&tabs=timeline&width=340&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                                </div>
                            </aside>
                        </div>
                    </div>