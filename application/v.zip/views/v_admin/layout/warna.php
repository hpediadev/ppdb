<?php
    
    $warna1 ='#0ecc5d';
        $warna2 ='#2f9258';
        $warna3 ='#09a048';
?>