<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>MA Al-Hasanah</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
   <link rel="icon" href="<?= base_url('uploads/icon.png')?>" type="image/png" sizes="16x16">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?= base_url('assets4/bootstrap/css/bootstrap.min.css')?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?= base_url('assets4/plugins/datatables/dataTables.bootstrap.css')?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url('assets4/dist/css/AdminLTE.min.css')?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url('assets4/dist/css/skins/_all-skins.min.css')?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <link rel="stylesheet" href="<?= base_url('assets4/dist/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')?>">
</head>
<body class="hold-transition skin-blue sidebar-mini layout-fixed fixed">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>MA</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Halaman Admin</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-fixed-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

              <?php
                $jumlah=0;
                if ($this->session->userdata("L")==1) {
                  $sdm = 'Super Admin';
                }
                else if ($this->session->userdata("L")==2) {
                  $sdm = 'Admin';
                }

                $jumlahpesan =  $this->db->get_where('tsaran_md',array('STATUSSARAN'=>'1'))->num_rows();
                    ?>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success"><?= $jumlahpesan; ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Anda Pusan <?= $jumlahpesan; ?> Pesan</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <?php
                  $this->db->order_by('IDSARAN DESC');
                  $sq = $this->db->get_where('tsaran_md', array('STATUSSARAN'=>1))->result();
                  foreach ($sq as $t) {

                  ?>
                  <li><!-- start message -->
                    <a href="<?= base_url('webadmsekolah/saran/id/'.$t->IDSARAN)?>">
                      <h4>
                        <?= substr($t->SUBJECT,0,20).' . . .'?>
                        <small><i class="fa fa-clock-o"></i> 5 mins</small>
                      </h4>
                      <p><?= substr($t->SARAN,0,40).' . . .'?></p>
                    </a>
                  </li>
                <?php }?>
                  <!-- end message -->
                  
                </ul>
              </li>
              <li class="footer"><a href="<?= base_url('webadmsekolah/saran/id/')?>">Semua Pesan</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          
          <!-- Tasks: style can be found in dropdown.less -->
         
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?= base_url('uploads/'.$this->session->userdata("G"))?>" class="user-image" alt="User Image">
              <span class="hidden-xs"></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?= base_url('uploads/'.$this->session->userdata("G"))?>" class="img-circle" alt="User Image">

                <p>
                  <?=  $this->session->userdata("N").'<br>'.$sdm;?>
                </p>
              </li>
              <!-- Menu Body -->
              
              <!-- Menu Footer-->
              <li class="user-footer">
               
                <div class="pull-right">
                  <a href="<?= base_url('loginadm/logout')?>" class="btn btn-default btn-flat">Keluar</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <!-- <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li> -->
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?= base_url('uploads/'.$this->session->userdata("G"))?>" class="img-circle" alt="User Image">
          
        </div>
        <div class="pull-left info">
          <p>
            <?php
                 echo $this->session->userdata("N");
        //         // set array of items in session
        //         $arraydata = array(
        //                 'author_name'  => 'Sajal Soni',
        //                 'website'     => 'http://code.tutsplus.com',
        //                 'twitter_id' => '@sajalsoni',
        //                 'interests' => array('tennis', 'travelling')
        //         );
        //         $this->session->set_userdata($arraydata);
        //     echo "Favourite Website: ". $this->session->userdata('favourite_website');
        // echo "<br>";
        // echo "Author Name: ". $this->session->userdata('author_name');
        // echo "<br>";
        // echo "Interest (Array Example): " . $this->session->userdata('interests')[0];
        // echo "<br>";

            ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>

            <br><br>
            <br><br>
        </div>
      </div>
      <!-- search form -->
     <!--  <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="">
          <a href="<?php echo base_url('webadmsekolah/beranda')?>">
            <i class="fa fa-table"></i> <span>Beranda</span>
            
          </a>
        </li>
        <?php
        if($this->session->userdata("L")==1){
          ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Sekolah</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('webadmsekolah/profilsekolah')?>"><i class="fa fa-circle-o"></i> Profil Sekolah</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Slide</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/slide')?>"><i class="fa fa-circle-o"></i> Data Slide</a></li>
            <li><a href="<?php echo base_url('webadmsekolah/slide/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Silde</a></li>
          </ul>
        </li>
      <?php }?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Artikel</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/artikel')?>"><i class="fa fa-circle-o"></i> Data Artikel</a></li>
            <li><a href="<?php echo base_url('webadmsekolah/artikel/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Artikel</a></li>
          </ul>
        </li>
        <?php
        if($this->session->userdata("L")==1){
          ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Tags</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/tags')?>"><i class="fa fa-circle-o"></i> Data Tags</a></li>
            <li><a href="<?php echo base_url('webadmsekolah/tags/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Tags</a></li>
          </ul>
        </li>
        <li class="treeview active">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Profil Sekolah</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo base_url('webadmsekolah/profil')?>"><i class="fa fa-circle-o"></i> Data Profil</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/profil/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Profil</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/sejarah')?>"><i class="fa fa-circle-o"></i> Data Sejarah</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/sejarah/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Sejarah</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/visimisi')?>"><i class="fa fa-circle-o"></i> Data Visi Misi</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/visimisi/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Visi Misi</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/struktur')?>"><i class="fa fa-circle-o"></i> Data Struktur</a></li>
          <li><a href="<?php echo base_url('webadmsekolah/struktur/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Struktur</a></li>
          
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Jurusan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/jurusan')?>"><i class="fa fa-circle-o"></i> Data Jurusan</a></li>
            <li><a href="<?php echo base_url('webadmsekolah/jurusan/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Jurusan</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Ekskul</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/ekskul')?>"><i class="fa fa-circle-o"></i> Data Ekskul</a></li>
            <li><a href="<?php echo base_url('webadmsekolah/ekskul/tambah')?>"><i class="fa fa-circle-o"></i> Tambah Ekskul</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Data Saran</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"><li><a href="<?php echo base_url('webadmsekolah/saran')?>"><i class="fa fa-circle-o"></i> Data Saran</a></li>
           </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Profil User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('webadmsekolah/profiluser')?>"><i class="fa fa-circle-o"></i> Data User</a></li>
             <li><a href="<?php echo base_url('webadmsekolah/profiluser/tambah')?>"><i class="fa fa-circle-o"></i> Tambah User</a></li>
           </ul>
        </li>
      <?php }?>
        <!-- <li><a href="../../documentation/index.html"><i class="fa fa-book"></i> <span>Documentation</span></a></li>
        <li class="header">LABELS</li>
        <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a></li>
        <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a></li>
        <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li> -->
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   