
    <!-- Main content -->


    <!-- Main content -->
    <section class="content">
      <div class="row">
        <?php 
        if(!empty($this->session->flashdata("rubah"))){
         ?>
        <div class="col-xs-12"> <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b><i class="icon fa fa-check"></i> Selamat...!. </b><?php echo $this->session->flashdata('rubah');  ?>
              </div>
            <?php }
        if(!empty($this->session->flashdata("data"))){
         ?>
        <div class="col-xs-12"> <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b><i class="icon fa fa-check"></i> Selamat...!. </b><?php echo $this->session->flashdata('data');  ?>
              </div>
            <?php }
        if(!empty($this->session->flashdata("gagal"))){
         ?>
        <div class="col-xs-12"> <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b><i class="icon fa fa-close"></i> Perhatian...!. </b><?php echo $this->session->flashdata('gagal');  ?>
              </div>
            <?php }
        if(!empty($this->session->flashdata("besar"))){
         ?>
        <div class="col-xs-12"> <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b><i class="icon fa fa-close"></i> Perhatian...!. </b><?php echo $this->session->flashdata('besar');  ?>
              </div>
            <?php }
        if(!empty($this->session->flashdata("png"))){
         ?>
        <div class="col-xs-12"> <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b><i class="icon fa fa-close"></i> Perhatian...!. </b><?php echo $this->session->flashdata('png');  ?>
              </div>
            <?php }
            ?> 
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Profil</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form role="form" method="post" enctype="multipart/form-data" action="<?= base_url('webadmsekolah/profil/simpanedit')?>">
              <table id="examsple1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Jenis </th>
                  <th>Isi</th>
                </tr>
                </thead>
                <tbody> 
                  <?php 
                  $no=0;
                  foreach ($DataArtikel as $row) {
                    $no++;

                                        ?>
                <tr>
                  <td><?php echo $row->NAMAPROFIL ?></td>
                  <td>
                    <input type="text" value="<?php echo $row->DATAPROFIL ?>" name="data[]">
                    <input type="hidden" value="<?php echo $row->IDPROFIL ?>" name="id[]">
                  </td>
                </tr>
                  <?php 
                }

                   ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Judul</th>
                  <th>
                    <input type="hidden" value="<?php echo $no ?>" name="j">

                    <button type="submit" class="btn btn-primary">Simmpan</button></th>
                </tr>
                </tfoot>
              </table>
            </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    