<?php
defined('BASEPATH') OR exit('No direct script access allowed');

foreach ($artikel as $row) {
  # code...

?>
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Edit Artikrel</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data" action="<?= base_url('webadmsekolah/artikel/simpanedit')?>">
              <div class="box-body">
              <div class="form-group">
                  <label>Kategori</label>
                  <select class="form-control" name="kate" required>
                    <option value="">Kategori</option>
                    <?php
                    if($row->KATEGORI=='berita'){

                      $berita = 'selected';
                      $info='';
                    }
                    else if($row->KATEGORI=='informasi'){

                      $berita = '';
                      $info = 'selected';
                    }

                    ?>
                    <option <?= $info ?> value="informasi">Informasi</option>
                    <option <?= $berita ?> value="berita">Berita Sekolah</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Judul</label>
                  <input type="text" class="form-control" id="" value="<?= $row->JUDUL?>" placeholder="Enter email" required minlength="34" name="judul" >
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Gambar Asal</label><br>
                  <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR);?>" width="250px">
                  <input type="hidden" id="exampleInputFile" required=""  value="<?= $row->IDARTIKEL ?>" name="id" >
                  <input type="hidden" id="exampleInputFile" required=""  value="<?= $row->GAMBAR ?>" name="gambarasal" >

                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Gambar</label>
                  <input type="file" id="exampleInputFile" requyired=""  value="" name="gambar" >

                </div>
                <div class="form-group">
                  <label>Sub</label>
                  <textarea name="sub" class="form-control" required="" rows="3" placeholder="Enter ..."><?= $row->SUB?></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Text</label>
                  <textarea name="art" class="ckeditor" required="" id="text-ckeditor"><?= $row->URAIAN?></textarea>
                </div>
              </div>
              <!-- /.box-body -->


              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Simmpan</button>
                 <a href="../../profilsekolah"><button type="button" class="btn btn-danger">Kembali</button></a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
<?php }?>