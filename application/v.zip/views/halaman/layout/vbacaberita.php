<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
                            <div id="tg-content" class="tg-content">
                                
                                
                                <section class="tg-sectionspace tg-haslayout">
                                    <div class="tg-latestnews">
                                    <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                        <h2>&nbsp;Baca Berita</h2>
                                        </div>
											<!---- ======START BERITA==== ---->
                                            <?php
											$idArt = 0;
                                                foreach ($dataartikel as $row) {
                                                	$idArt = $row->IDARTIKEL;
                                                    # code...
                                                   $tanggal = substr($row->TANGGALARTIKEL, 0,10);
                                                   $jdl = str_replace(" ","-",$row->JUDUL);
                                                     $hari   = date('N', strtotime($tanggal)); 
                                                     $day = array('Senin','Selasa', 'Rabu','Kamis','Jumat','Sabtu','Ahad');
                                                     $bln = array('','Januari','Februari','Maret','April','Juni','Juli','Agustus','September','Oktober','November','Desember');
                                                     $tgl   = date('d ', strtotime($tanggal)).$bln[date('n', strtotime($tanggal))].date(' Y ', strtotime($tanggal)); 
                                                     //echo date('N', strtotime('2021-03-21'));
                                                
                                            ?>
										<article class="tg-themepost tg-newspost">
										<!-- <div class="tg-themsepostcontent">
											<div class="tg-themeposttitle">
												<h1>Allotment of Hostel Accommodation 2017!</h1>
											</div>
											<ul class="tg-themepostinfo">
												<li>
													<figure><a href="javascript:void(0);"><img src="images/authors/img-01.jpg" alt="image description"></a></figure>
													<div class="tg-infodata">
														<span>Tutor:</span>
														<strong><a href="javascript:void(0);">Antione Wattley</a></strong>
													</div>
												</li>
												<li>
													<div class="tg-infodata">
														<span>Member Joined:</span>
														<strong><a href="javascript:void(0);">1205 Members Joined</a></strong>
													</div>
												</li>
												<li>
													<div class="tg-infodata">
														<span>Total Views:</span>
														<strong><a href="javascript:void(0);">1205 People Visited</a></strong>
													</div>
												</li>
											</ul>
										</div> -->
										<figure class="tg-featuredimg">
                                                        <center href="javascript:void(0);" >
                                                            <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR)?>" alt="image description">
                                                        </center>
                                                    </figure>
										<div class="tg-themepostcontent">
											<div class="tg-themeposttitle">
												<h4><?= $row->JUDUL ?></h4>
												<h4><?= $row->TANGGALARTIKEL ?></h4>
											</div>
									<!-- 		<ul class="tg-matadata">
                                                            <li>
                                                                <a href="javascript:void(0);">
                                                                    <i class="fa fa-calendar"></i>
                                                                    <span><?= $day[$hari].','.$tgl ?></span>
                                                                </a>
                                                            </li>
                                                        </ul>  -->
										<div class="tg-description">
											<?= str_replace('<p align="justify">','',str_replace('</blockquote>','</q></blockquote>',str_replace('<blockquote>','<blockquote><q>', $row->URAIAN))) ?> 
<!-- 
											<a href="http://www.facebook.com/sharer.php?u=https://ma-alhasanahpasean.sch.id/berita/read/1/Selamat-dan-Sukses--UMBKS-2020-2021.html" target="_blank">Share To Facebook</a>
 -->
											<a href="http://www.facebook.com/sharer.php?u=<?= base_url() ?>berita/read/<?= $this->uri->segment(3)?>/<?= $this->uri->segment(4)?>.html" target="_blank">Share To Facebook</a>

										</div>
									</article>

									
									<?php } ?>

                                            	<!---- ======END BERITA==== ---->
									<div class="tg-tagsandpsotshares">
										<!-- <div class="tg-tagstext">
											<span>tags:</span>
											<div class="tg-tags">
												<a class="tg-tag" href="javascript:void(0);">Student</a>
												<a class="tg-tag" href="javascript:void(0);">Examination</a>
												<a class="tg-tag" href="javascript:void(0);">Easy Learning</a>
												<a class="tg-tag" href="javascript:void(0);">Pencils</a>
												<a class="tg-tag" href="javascript:void(0);">Technology</a>
												<a class="tg-tag" href="javascript:void(0);">Video</a>
												<a class="tg-tag" href="javascript:void(0);">Teachers</a>
												<a class="tg-tag" href="javascript:void(0);">Amazing Trips</a>
												<a class="tg-tag" href="javascript:void(0);">News</a>
												<a class="tg-tag" href="javascript:void(0);">Bully Kids</a>
											</div>
										</div> -->
										<div class="tg-sharetext">
											<span>share:</span>
											<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="http://www.facebook.com/sharer.php?u=https://ma-alhasanahpasean.sch.id/berita/read/<?= $this->uri->segment(3)?>/<?= $this->uri->segment(4)?>.html"><i class="fa fa-facebook"></i></a></li>
												
												<li class="tg-twitter"><a href="http://www.twitter.com/sharer?url=https://ma-alhasanahpasean.sch.id/berita/read/<?= $this->uri->segment(3)?>/<?= $this->uri->segment(4)?>.html"><i class="fa fa-twitter"></i></a></li>
												
												<li class="tg-twitter"><a href="whatsapp://send?text==https://ma-alhasanahpasean.sch.id/berita/read/<?= $this->uri->segment(3)?>/<?= $this->uri->segment(4)?>.html"><i class="fa fa-whatsapp"></i></a></li>

												<!-- <li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
												<li class="tg-skype"><a href="javascript:void(0);"><i class="fa fa-skype"></i></a></li>
												<li class="tg-dropbox"><a href="javascript:void(0);"><i class="fa fa-dropbox"></i></a></li>
												<li class="tg-vimeo"><a href="javascript:void(0);"><i class="fa fa-vimeo"></i></a></li>
												<li class="tg-stumbleupon"><a href="javascript:void(0);"><i class="fa fa-stumbleupon"></i></a></li>
												<li class="tg-yahoo"><a href="javascript:void(0);"><i class="fa fa-yahoo"></i></a></li>
												<li class="tg-pinterestp"><a href="javascript:void(0);"><i class="fa fa-pinterest"></i></a></li>
												<li class="tg-youtube"><a href="javascript:void(0);"><i class="fa fa-youtube"></i></a></li> -->
											</ul>
										</div>
									</div>

									<ul class="tg-postnav">
										<?php
											$no=0;
											$b=10;
											$j=0;
											$g=0;
                                                foreach ($nextNews as $r) {

                                            ?>

											<li>
												<figure style="width:100px"><img src="<?= base_url('uploads/artikel/'.$r->GAMBAR)?>" alt="image description"></figure>
												<div class="tg-postnavcontent">
													<a href="javascript:void(0);">Previous News</a>
													<h3><a href="<?=  base_url()?>berita/read/<?= $r->IDARTIKEL.'/'.$r->LINK.'.html'; ?>">
														<?= $r->JUDUL?>
													</a></h3>
												</div>
											</li>
                                            <?php 
                                                }
                                            ?>
									</ul>
									<ul class="tg-postnav">
										<?php
										$idArt =$this->uri->segment(3);
										$ind=1;
										$i=0;
										$kur=1;
										$idArray ='';
										$judulArt = '';
										$gambar = '';
										foreach($prevnext as $pr){
											// $idf[]= $pr->IDARTIKEL;
											// if($idf==$idArt)
											// {
											// 	$i=$ind-$kur;
											// 	//$prev=$pr->IDARTIKEL;
											// 	$z=$ind+$kur;
											// 	echo $i.'|'.$z;
											// 	echo $idf[$ind];
											// }
											//echo $pr->IDARTIKEL.'<br>';
											$idArray=$idArray.''.$pr->IDARTIKEL.',';
											$judulArt=$judulArt.''.$pr->JUDUL.'|';
											$gambar=$gambar.''.$pr->GAMBAR.'|';
											
											//$ind++;
										}
										//echo $judulArt;
										$jdlA = $judulArt;
										$text = $idArray;
										$gam = $gambar;
										$hobi=explode(",", $text);
											//echo "<p>Hasilnya Ketika Menggunakan fungsi Explode</p><pre>";
									
											//print_r($hobi);
										
											//echo "</pre>";
										$textjudul=explode("|", $jdlA);
										$textgambar=explode("|", $gam);
											//echo "<p>Hasilnya Ketika Menggunakan fungsi Explode</p><pre>";
									
											//print_r($textjudul);
										
											//echo "</pre>";
										
										 
										
											foreach ($hobi as $key => $data) {
										
												//echo "index : $key Nilai : $data<br/>";
												if($data==$idArt)
												{
													$p=$key-1;
													$n=$key+1;
													if($p<0)
													$p=$key;
													//echo $data.' | '.$idArt;
												}
										
											}
											//echo "Prev : ".$hobi[$p];
											//echo "<br>Next : ".$hobi[$n];
											//echo "<br>Next : ".$textjudul[$n];
										//if($p<0){
									?>
										<!-- <li>
											<a href="http://www.facebook.com/sharer.php?u=<?=  base_url()?>berita/read/<?= $idArt.'/'.str_replace(" ","-",$idArt =$this->uri->segment(4)).'.html'; ?>" target="_blank">Share To Facebook</a>
										</li>
										
										<li>
											<div class="tg-postnavcontent">
											<figure><img id="sedbagian" width="100px" src="<?=  base_url('uploads/artikel/'.$textgambar[$p])?>" alt="image description"></fegure>
											
											</div><a href="<?=  base_url()?>berita/read/<?= $hobi[$p].'/'.str_replace(" ","-",$textjudul[$p]).'.html'; ?>">Berita Selanjutnya</a><br>
											<b><a href="<?=  base_url()?>berita/read/<?= $hobi[$p].'/'.str_replace(" ","-",$textjudul[$p]).'.html'; ?>"><b style="color: #333"><?= $textjudul[$p]?></b></a></b>
										</li> 
										<li>
											<div class="tg-postnavcontent">
											<figure><img id="sebdagian" width="100px" src="<?=  base_url('uploads/artikel/'.$textgambar[$n])?>" alt="image description"></fegure>
											
											</div><a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>">Berita Selanjutnya</a><br>
											<b><a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>"><b style="color: #333"><?= $textjudul[$n]?></b></a></b>
										</li>  -->
									</ul>
									<!-- div class="col-xs-12 col-sm-8 col-md-9 col-lg-2 " style="text-align: left;">
										<p clas="gambar" style="width: 70px;height: 70px" style="text-align: right; border: 1px solid"><img id="sebagian" src="<?=  base_url('uploads/artikel/'.$textgambar[$n])?>" alt="image description"></p>
									</div>
									<div class="col-xs-12 col-sm-8 col-md-9 col-lg-3 " style="text-align: left;">
										<a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>">Berita Selanjutnya</a>
											<p><a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>"><?= $textjudul[$n]?></a></p>
									</div>
									<div class="col-xs-12 col-sm-8 col-md-9 col-lg-2 " style="text-align: left;">
									</div>

									<div class="col-xs-12 col-sm-8 col-md-9 col-lg-3 " style="text-align: RI;">
										<a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>">Berita Selanjutnya</a>
											<p><a href="<?=  base_url()?>berita/read/<?= $hobi[$n].'/'.str_replace(" ","-",$textjudul[$n]).'.html'; ?>"><?= $textjudul[$n]?></a></p>
									</div>


									<div class="col-xs-12 col-sm-8 col-md-9 col-lg-2 pull-right" style="text-align: left;">
										<p clas="gambar" style="width: 70px;height: 70px" style="text-align: right; border: 1px solid"><img id="sebagian" src="<?=  base_url('uploads/artikel/'.$textgambar[$n])?>" alt="image description"></p>
									</div> -->

									

									
									<!-- <div class="tg-postauthor">
										<figure><a href="javascript:void(0);"><img src="images/img-18.jpg" alt="image description"></a></figure>
										<div class="tg-postauthorcontent">
											<div class="tg-postauthorhead">
												<h4><a href="javascript:void(0);">Maragaret Ellinger</a></h4>
												<span>Author Since: June 27, 2015</span>
												<ul class="tg-socialicons">
													<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
													<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
													<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
													<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
													<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
												</ul>
											</div>
											<div class="tg-description">
												<p>Consequat duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat nullataka pariatur occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum perspiciatis undes omnis iste natus error sit quae ab illo inventore irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat ananulla pariatur occaecat cupidatat non dolore eu fugiat nullataka pariatur.</p>
											</div>
										</div>
									</div> -->
									<!-- <div class="tg-relatedthemeposts">
										<div class="tg-borderheading">
											<h2>Related News</h2>
										</div>
										<div id="tg-latestnewsslider" class="tg-latestnewsslider owl-carousel tg-posts">
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-04.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">Take a Step &amp; Become a Proffesional Teacher</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-05.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">One Day Crash Course on Skills Improvement</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-06.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">An Apple A Day Keeps The Teacher Away</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-07.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">Degree In Hand And A Job In Your Pocket</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-08.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">Ending? This Is Only The Beginning Ending This Is Only The</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
											<div class="item">
												<article class="tg-themepost tg-newspost">
													<figure class="tg-featuredimg">
														<a href="javascript:void(0);">
															<img src="images/courses/img-09.jpg" alt="image description">
														</a>
													</figure>
													<div class="tg-themepostcontent">
														<ul class="tg-matadata">
															<li>
																<a href="javascript:void(0);">
																	<i class="fa fa-calendar"></i>
																	<span>Tuesday, Apr 21, 2017</span>
																</a>
															</li>
														</ul>
														<div class="tg-themeposttitle">
															<h3><a href="javascript:void(0);">I Use To Be Little, But Now I'm Going To School</a></h3>
														</div>
														<div class="tg-description">
															<p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
														</div>
													</div>
												</article>
											</div>
										</div>
									</div>
									<div class="tg-commentssection">
										<div class="tg-titleborder">
											<h2>03 Comments</h2>
										</div>
										<ul id="tg-comments" class="tg-comments">
											<li>
												<div class="tg-comment">
													<figure><a href="javascript:void(0);"><img src="images/img-19.jpg" alt="image description"></a></figure>
													<div class="tg-commentcontent">
														<div class="tg-commenthead">
															<h4><a href="javascript:void(0);">Machelle Paolini</a></h4>
															<span>June 27, 2015</span>
															<a class="tg-btncommentreply" href="javascript:void(0);">
																<i class="fa fa-reply"></i>
																<em>reply</em>
															</a>
														</div>
														<div class="tg-description">
															<p>Consequat duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat nullataka pariatur occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum perspiciatis undes omnis iste natus error sit quae ab illo inventore irure dolor in reprehenderit voluptate.</p>
														</div>
													</div>
												</div>
												<ul class="tg-commentchild">
													<li>
														<div class="tg-comment">
															<figure><a href="javascript:void(0);"><img src="images/img-20.jpg" alt="image description"></a></figure>
															<div class="tg-commentcontent">
																<div class="tg-commenthead">
																	<h4><a href="javascript:void(0);">Machelle Paolini</a></h4>
																	<span>June 27, 2015</span>
																	<a class="tg-btncommentreply" href="javascript:void(0);">
																		<i class="fa fa-reply"></i>
																		<em>reply</em>
																	</a>
																</div>
																<div class="tg-description">
																	<p>Consequat duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat nullataka pariatur occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum perspiciatis undes omnis iste natus error voluptate.</p>
																</div>
															</div>
														</div>
													</li>
												</ul>
											</li>
											<li>
												<div class="tg-comment">
													<figure><a href="javascript:void(0);"><img src="images/img-21.jpg" alt="image description"></a></figure>
													<div class="tg-commentcontent">
														<div class="tg-commenthead">
															<h4><a href="javascript:void(0);">Machelle Paolini</a></h4>
															<span>June 27, 2015</span>
															<a class="tg-btncommentreply" href="javascript:void(0);">
																<i class="fa fa-reply"></i>
																<em>reply</em>
															</a>
														</div>
														<div class="tg-description">
															<p>Consequat duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore eu fugiat nullataka pariatur occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum perspiciatis undes omnis iste natus error sit quae ab illo inventore irure dolor in reprehenderit voluptate.</p>
														</div>
													</div>
												</div>
											</li>
										</ul>
									</div>
									<div class="tg-postcomments">
										<div class="tg-titleborder">
											<h2>Leave Your Comment</h2>
										</div>
										<form class="tg-formtheme tg-formpostcomment">
											<fieldset>
												<div class="form-group">
													<input type="text" name="name" class="form-control" placeholder="Name*">
												</div>
												<div class="form-group">
													<input type="email" name="email" class="form-control" placeholder="Email* (Your email address will not be published.)">
												</div>
												<div class="form-group">
													<input type="text" name="subject" class="form-control" placeholder="Subject">
												</div>
												<div class="form-group">
													<textarea  name="Comment" class="form-control" placeholder="Comment"></textarea>
												</div>
												<button class="tg-btn" type="submit">submit</button>
											</fieldset>
										</form>
									</div> -->
									</div>
                                </section>

                                
                            </div>
                        </div>