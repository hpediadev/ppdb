<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
    <div id="tg-content" class="tg-content">
        <section class="tg-sectionspace tg-haslayout">
            <div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="tg-glanceatuoeandk tg-glanceatuoeandkvtwo">
                        <div class="tg-borderheading sidebar">
									<div class="split"></div>
                                            <h2>&nbsp;&nbsp;Hubung Kami</h2>
                        </div>
					<!-- 	<article class="tg-themepost tg-newspost">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4048549.6482837764!2d110.3861052649495!3d-7.7193922098619785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd9cf7792deab95%3A0x8302802cc08cb4ca!2sSMK%20PUTRA%20BANGSA!5e0!3m2!1sen!2sid!4v1615785734003!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
									</article> -->
									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.7643146762366!2d113.6179460140326!3d-6.918755395000899!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd9c5cad284ad51%3A0x7d30279d215a2634!2sMA%20AL-HASANAH!5e0!3m2!1sid!2sid!4v1616076759790!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
									
									
									<div class="tg-themepostcontent">
									<form class="tg-formtheme tg-formcontactus" action="<?= base_url('bantuan/simpan.html')?>" method="post">
										<fieldset>
											<div class="row">
												<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
													<div class="form-group">
														<input type="text" maxlength="30" required class="form-control" name="nama" placeholder="Nama">
													</div>
												</div>
												<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
													<div class="form-group">
														<input type="email" maxlength="30" required  class="form-control" name="email" placeholder="Email (Email Anda Aman Tidak Ditampilkan.)">
													</div>
												</div>
												<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
													<div class="form-group">
														<input type="text" maxlength="100" required class="form-control" name="subject" placeholder="Subject">
													</div>
												</div>
												<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
													<div class="form-group">
														<textarea class="form-control" required  placeholder="Comment" name="pesan"></textarea>
														
													</div>
												</div>
												<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
													<button class="tg-btn" type="subsmit">submit</button>
												</div>
											</div>
										</fieldset>
									</form>
										</div>
                    </div>
                </div>
                
            </div>
        </section>
    </div>
</div>