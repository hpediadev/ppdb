                   
  <div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
        <div id="tg-content" class="tg-content">
        <section class="tg-sectionspace tg-haslayout">
                <div class="row">
                    
                    
                    <div class="col-xs-12 col-sm-8 col-md-9 col-lg-12">		
                          <!-- S -->
                    <div id="slideshow-mudah" class="carousel slide" data-ride="carousel">
                          <!-- Indicators, Ini adalah Tombol BULET BULET dibawah. item ini dapat dihapus jika tidak diperlukan -->
                          <ol class="carousel-indicators">
                          <?php 
							$no=0;
							$k='';
							$nno=0;
            				$kk='';

                            $slide = $this->db->order_by('IDSLIDE ASC');
                            $slide = $this->db->limit(3);
                            $slide = $this->db->get('tslide_md')->result();
							foreach ($slide as $row) {
								if($no==0)
									$k='active';
								else
									$k='';
									$idwows = 'wows1_'.$no;
							?>
                            <li data-target="#slideshow-mudah" data-slide-to="<?= $no ?>" class="<?= $k ?>"></li>
                            <?php $no++;} ?>
                          </ol>
                         
                          <!-- Wrapper for slides, Ini adalah Tempat Gambar-->
                          <div class="carousel-inner">
                          <?php 
							$no=0;
							$k='';
							$nno=0;
            				$kk='';

                            $slide = $this->db->order_by('IDSLIDE ASC');
                            $slide = $this->db->limit(3);
                            $slide = $this->db->get('tslide_md')->result();
							foreach ($slide as $row) {
								if($no==0)
									$k='active';
								else
									$k='';
									$idwows = 'wows1_'.$no;
							?>
                            <div class="item <?= $k ?>">
                              <img  alt="slideshow-mudah" src="<?php echo base_url('uploads/'.$row->GAMBAR)?>"> <!—Gambar -->
                              <div class="carousel-caption"> <!--Penjelasan 
                                <h3>Slide 1 (Judul)</h3>
                                <p>Ini adalah Slide 1 (Penjelasan)</p>-->
                              </div>
                            </div>
                            <?php $no++;} ?>
                             
                            
                          </div>
                         
                          <!-- Controls, Ini adalah Panah Kanan dan Kiri. item ini dapat dihapus jika tidak diperlukan-->
                          <a class="left carousel-control" href="#slideshow-mudah" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                          </a>
                          <a class="right carousel-control" href="#slideshow-mudah" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                          </a>
                        </div>
                          <!-- S -->
		<!--		sssssssssssssssssssss--

								<div id="wowslider-container1">
									<div class="ws_images">
									<ul>
									<?php 
										$no=0;
										$k='';
										$nno=0;
                        				$kk='';

                                        $slide = $this->db->order_by('IDSLIDE ASC');
                                        $slide = $this->db->limit(3);
                                        $slide = $this->db->get('tslide_md')->result();
										foreach ($slide as $row) {
											if($no==0)
												$k='active';
											else
												$k='';
												$idwows = 'wows1_'.$no;
										?>
										<li class="<?= $idwows?>"><img src="<?php echo base_url('uploads/'.$row->GAMBAR)?>" stsylde="width:425px;" id="<?= $no?>"/></li>
										<?php $no++;} ?>
									</ul>
									</div>                                                    
									<div class="ws_script" style="position:absolute"></div>
									<div class="ws_shadow"></div>
								</div>
								<script type="text/javascript" src="<?= base_url('assets/slideshow/engine1/wowslider.js')?>"></script>
								<script type="text/javascript" src="<?= base_url('assets/slideshow/engine1/script.js')?>"></script>
								
							
				</div>
		<!--		sssssssssssssssssssss-->
  <!--                  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">-->
  <!--                      <div class="tg-widget tg-widgetquicklinks tg-widgetquicklinksvtwo">-->
                            
  <!--                          <div class="tg-widgetcontent">-->
  <!--                          <div id="myCarousel" class="carousel slide" data-ride="carodusel">-->
		<!--		<ol class="carousel-indicators">-->
		<!--			<s?php -->
		<!--		$no=0;-->
		<!--		$k='';-->
		<!--		$nno=0;-->
		<!--		$kk='';-->
  <!--              $slide = $this->db->get('tslide_md')->result();-->
		<!--		foreach ($slide as $row) {-->
		<!--			if($no==0)-->
		<!--				$k='active';-->
		<!--			else-->
		<!--				$k='';-->
		<!--		?>-->
		<!--			<li data-target="#myCarousel" data-slide-to="<?= $no ?>" class="<?= $k ?>"></li>-->
		<!--<s?php $no++;} ?>-->
		<!--		</ol>-->
		<!--		<div class="carousel-inner" role="lisstbox" style="border: 0px solid red;">-->
		<!--	<s?php foreach ($slide as $row) {-->
		<!--		if($nno==0)-->
		<!--				$kk='active';-->
		<!--			else-->
		<!--				$kk='';-->
		<!--			$nno++;-->
		<!--		?>-->
		<!--			<div class="item <?= $kk ?>">-->
		<!--				<img src="<?php echo base_url('uploads/'.$row->GAMBAR)?>" style="width:100%;" alt="" />-->
						
		<!--			</div>	-->
		<!--<s?php } ?>-->
		<!--		</div>-->
		<!--		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">-->
		<!--			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>-->
		<!--			<span class="sr-only">Previous</span>-->
		<!--		</a>-->
		<!--		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">-->
		<!--			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>-->
		<!--			<span class="sr-only">Next</span>-->
		<!--		</a>-->
		<!--	</div>-->
  <!--                          </div>-->
  <!--                      </div>-->
  <!--                  </div>-->
                </div>
            </section>
            <section class="tg-sectionspace tg-haslayout">
                <div class="tg-borderheading sidebar">
                <div class="split"></div>
                    <h2>&nbsp;Informasi Terbaru</h2>
                </div>
                <!-- <div class="tg-borderheading">
                    <h2>Latest Events</h2>
                </div> -->
                <div class="tg-events">
                    <div class="row">
                        <?php
                        // $no = $this->uri->segment('3') + 1;
                            foreach ($user as $row) {
                                # code...
                                $jdl = str_replace(" ","-",$row->JUDUL);
                                $tanggal = substr($row->TANGGALARTIKEL, 0,10);
                                   $hari   = date('N', strtotime($tanggal)); 
                                                     $day = array('','Senin','Selasa', 'Rabu','Kamis','Jumat','Sabtu','Ahad');
                                                     $bln = array('','Januari','Februari','Maret','April','Juni','Juli','Agustus','September','Oktober','November','Desember');
                                                     $tgl   = date('d ', strtotime($tanggal)).$bln[date('n', strtotime($tanggal))].date(' Y ', strtotime($tanggal)); 
                                    //echo "Tanggal $tanggal adalah hari " . $hari;
                                    // Tanggal 2017-01-31 adalah hari Tuesday
                            
                        ?>
                        <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
                            <article class="tg-themepost tg-eventpost">
                                <figure class="tg-featuredimg">
                                <a href="javascript:void(0);" style="width: 100%; height: 150px; overflow: hidden;position: relative;">
                                        <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR)?>" alt="image description">
                                    </a>
                                    <!-- <a href="javascript:void(0);">
                                        <img src="<?= base_url('uploads/artikel/'.$row->GAMBAR)?>" alt="image description" alt="image description">
                                    </a> -->
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span><?= $day[$hari].','.$tgl ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="<?=  base_url()?>berita/read/<?= $row->IDARTIKEL.'/'.$row->LINK.'.html'; ?>"><?= $row->JUDUL ?></a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p><?= substr($row->SUB,0,50) ?>... <a href="<?=  base_url()?>berita/read/<?= $row->IDARTIKEL.'/'.$jdl.'.html'; ?>">Baca Selanjutnya</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                    <?php } ?>
                        
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 center">
                            <center class="tg-themepost tg-eventpost">
                                <?php echo $this->pagination->create_links(); ?>
                            </center>
                        </div>
                </div>
            </section><section class="tg-sectionspace tg-haslayout">
                <div class="tg-borderheading sidebar">
                <div class="split"></div>
                    <h2>&nbsp;Youtube </h2>
                </div>
                <!-- <div class="tg-borderheading">
                    <h2>Latest Events</h2>
                </div> -->
                <div class="tg-events">
                    <div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-12 col-lg-12">
                            <article class="tg-themepost tg-eventpost">
                               <?php
                               $sp = $this->db->get('tlembaga_md')->result();
                               $youtube='';
                               foreach ($sp as $lem) {
                                $youtube = $lem->YOUTUBE;
                               }
                               ?>
                                <div class="tg-themepostcontent">
                                   <iframe width="100%" height="515" src="https://www.youtube.com/embed/<?= $youtube ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                            </article>
                        </div>
                        
                    </div>
                </div>
            </section>
            <!-- <section class="tg-sectionspace tg-haslayout">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                        <div class="tg-glanceatuoeandk tg-glanceatuoeandkvtwo">
                            <div class="tg-borderheading">
                                <h2>Glance at UOE&amp;K</h2>
                            </div>
                            <ul class="tg-gallery">
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-22.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-22.jpg" alt="image description">
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-01.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-01.jpg" alt="image description">
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-02.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-02.jpg" alt="image description">
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-03.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-03.jpg" alt="image description">
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-04.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-04.jpg" alt="image description">
                                    </figure>
                                </li>
                                <li>
                                    <figure>
                                        <a class="tg-btnview" href="images/glance/img-05.jpg" data-rel="prettyPhoto[glance]"><i class="icon-magnifier"></i></a>
                                        <img src="images/glance/img-05.jpg" alt="image description">
                                    </figure>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                        <div class="tg-widget tg-widgetquicklinks tg-widgetquicklinksvtwo">
                            <div class="tg-borderheading">
                                <h2>Link Sekolah</h2>
                            </div>
                            <div class="tg-widgetcontent">
                                <ul>
                                    <li><a href="javascript:void(0);">PPDB</a></li>
                                    <li><a href="javascript:void(0);">E-Learning</a></li>
                                    <li><a href="javascript:void(0);">Osis</a></li>
                                    <li><a href="javascript:void(0);">PPDB</a></li>
                                    <li><a href="javascript:void(0);">PPDB</a></li>
                                    <li><a href="javascript:void(0);">PPDB</a></li>
                                    <li><a href="javascript:void(0);">PPDB</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="tg-sectionspace tg-haslayout">
                <div class="tg-latestnews">
                    <div class="tg-borderheading">
                        <h2>Latest News</h2>
                    </div>
                    <div id="tg-latestnewsslider" class="tg-latestnewsslider owl-carousel tg-posts">
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-05.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Allotment of Hostel Accommodation 2017!</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-06.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Notification of Mid Term Examinations</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-07.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Invites Application for Admission in Designing Program</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-05.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Allotment of Hostel Accommodation 2017!</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-06.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Notification of Mid Term Examinations</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="item">
                            <article class="tg-themepost tg-newspost">
                                <figure class="tg-featuredimg">
                                    <a href="javascript:void(0);">
                                        <img src="images/themepost/img-07.jpg" alt="image description">
                                    </a>
                                </figure>
                                <div class="tg-themepostcontent">
                                    <ul class="tg-matadata">
                                        <li>
                                            <a href="javascript:void(0);">
                                                <i class="fa fa-calendar"></i>
                                                <span>Tuesday, Apr 21, 2017</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tg-themeposttitle">
                                        <h3><a href="javascript:void(0);">Invites Application for Admission in Designing Program</a></h3>
                                    </div>
                                    <div class="tg-description">
                                        <p>Consectetur adipisicing elit sed do eiusmod tempor inunt labore... <a href="javascript:void(0);">Read More</a></p>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>
                    <div class="tg-btnsbox">
                        <a class="tg-btn" href="javascript:void(0);">view all news</a>
                    </div>
                </div>
            </section> -->
        </div>
    </div>