YAYASAN AL-MUSTAQIM
	SMK PUTRA BANGSA	
WARU PAMEKASAN
Alamat : Jl. Pontren Al-Mustaqim Waru Barat Kec. Waru Kab. Pamekasan

website : http://www.smkpb.sch.id, email :info@smkpb.sch.id

RENCANA PELAKSANAAN PEMBELAJARAN 
(RPP )

Satuan Pendidikan	: SMK Putra Bangsa
Mata Pelajaran 	: 
Kelas/ Semester	: 
Materi Pokok		: 
Alokasi Waktu		: 
A.	Kompetensi Inti (KI)

B.	Kompetensi Dasar (KD), Indikator Pencapaian Kompetensi 

No	KOMPETENSI DASAR	INDIKATOR PENCAPAIAN KOMPETENSI
	Kompetensi Pengetahuan

	
	Kompetensi Keterampilan	

C.	Tujuan Pembelajaran


D.	Materi Pembelajaran


E.	Metode Pembelajaran


F.	Media Pembelajaran

G.	Sumber belajar

H.	Langkah-langkah Kegiatan Pembelajaran

Pertemuan Ke....
TAHAP PEMBELAJARAN	KEGIATAN PEMBELAJARAN	ALOKASI WAKTU
A.	Kegiatan Pendahuluan
Pendahuluan
(persiapan/orientasi)		

Apersepsi		
Motivasi



		
B.	Kegiatan Inti
Sintak Model Pembelajaran 1

		
Sintak Model Pembelajaran 1 

		
Sintak Model Pembelajaran dst


	





	
C.	Kegiatan Penutup

I.	Penilaian

a.	Teknik Penilaian

1)	Sikap




2)	Keterampilan

3)	Pengetahuan

b.	Pembelajaran Remedial dan Pengayaan 




J.	Bahan Ajar

