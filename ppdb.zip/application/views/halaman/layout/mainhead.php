<div class="tg-tickerbox">

            <div class="container">
                <div class="row ">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">  
                    <?php $warna2="red"; ?>
                        <span  id="warna2">Informasi Terbaru :</span>
                        <div id="tg-ticker" class="tg-ticker owl-carousel">
                            <div class="item">
                               <!--  <div class="tg-description">
                                    <p>Info Pembekalan Tahun Praktik Kerja Lapangan akan dilakukan hari senin12 Juni 2022, Informasi Lebih Lanjut <a href="" style="background-color: <?= $warna2?>; padding: 2px;color: white;" id="warna2"><b> Klik Disini </b></a></p>
                                </div> -->
                                
                                    <marquee>Selamat Datang di SMK Putra Bangsa Waru Barat Waru Pamekasan, Segera Bergabun dengan Kami dan Nikmati Digital School Program</marquee>
                            </div>
                             <!-- <div class="item">
                                <div class="tg-description">
                                    <p>Info Kegiatan KBM akan dilakukan hari senin12 Juni 2022, Informasi Lebih Lanjut <a href="" style="padding: 2px;padding-left: 2px;padding-right: 2px;color: white;" id="warna2"><b> Klik Disini </b></a></p>
                                </div>
                            </div>
                             <div class="item">
                                <div class="tg-description">
                                    <p>Info Wisuda Akhir Tahun  akan dilakukan hari senin12 Juni 2022, Informasi Lebih Lanjut <a href="" style="padding: 2px;color: white;" id="warna2"><b> Klik Disini </b></a></p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                Home Slider End
        *************************************-->
        <!--************************************
                Main Start
        *************************************-->
        

        
       
        <main id="tg-main" class="tg-main tg-haslayout">
            <div class="container">
                <div class="row">
                    <div id="tg-twocolumns" class="tg-twocolumns">
                        <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <section class="tg-sectionspace tg-haslayout">
                                <div class="tg-shortcode tg-welcomeandgreeting tg-welcomeandgreeting-v2">
                                    <figure><img src="<?= base_url('assets/images/img-03.jpg')?>" alt="image description"></figure>
                                    <div class="tg-shortcodetextbox">
                                        <h2>Welcome &amp; Greetings!</h2>
                                        <div class="tg-description">
                                            <p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore et dolore amit agna aliqua enimnate minim veniam quis nostrud exercitation ullamco laboris nisi utiata ...</p>
                                        </div>
                                        <span class="tg-name">Prof. Donovan Bradburn</span>
                                        <span class="tg-designation">Vice Chancellor</span>
                                        <div class="tg-btnpluslogo">
                                            <a class="tg-btn" href="javascript:void(0);">read more</a>
                                            <strong class="tg-universitylogo"><a href="javascript:void(0);"><img src="<?= base_url('assets/images/logo2.png')?>" alt="image description"></a></strong>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div> -->
                        
