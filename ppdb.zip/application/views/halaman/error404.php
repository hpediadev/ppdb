<main id="tg-main" class="tg-main tg-haslayout">
			<div class="container">
				<div class="row">
					<div class="tg-404error">
						<figure class="tg-errorimg">
							<img src="<?= base_url('uploads/')?>404-img.jpg" alt="image description">
						</figure>
						<div class="tg-errorcontent">
							<div class="col-sm-10 col-sm-offset-1">
								<h2>Ooops!</h2>
								<h3>Spertinya Anda Mengakses<span>Halaman Terlarang?</span></h3>
								<div class="tg-description">
									<p>Maaf, kami tidak dapat menemukan halaman yang Anda cari. Silakan pergi ke<a href="<?= base_url()?>">Home</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>