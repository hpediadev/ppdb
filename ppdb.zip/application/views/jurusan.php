 <!-- =====================================
    	==== Start services -->
      <div gray-bg class="services section-padding" data-scroll-index="2">
        <div class="container">
          <!-- section-head -->
          <div class="section-head text-center">
            <h2 data-text="Services"> <span>Our Services</span> </h2>
          </div>

          <!-- our services items -->
          <div class="content">
            <div class="row">
              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="fas fa-desktop"></i></span>
                  </div>
                  <h4>Web Devlopment</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>

              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="fas fa-pen-nib"></i></span>
                  </div>
                  <h4>Creative Design</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>

              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="fas fa-mobile-alt"></i></span>
                  </div>
                  <h4>Fully Responsive</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>

              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="far fa-clone"></i></span>
                  </div>
                  <h4>Easy Customize</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>

              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="fas fa-globe-americas"></i></span>
                  </div>
                  <h4>Seo Optimized</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>

              <div class="col-lg-4">
                <div class="items text-center">
                  <div class="icon">
                    <span><i class="fas fa-headset"></i></span>
                  </div>
                  <h4>Full Support</h4>
                  <p>Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an cule dicta iriure at phaedrum.</p>
                </div>
              </div>
               <!-- end services items -->

            </div>
          </div>
        </div>
      </div>
    <!-- =====================================
    	==== end services -->