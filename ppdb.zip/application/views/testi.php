
    <!-- =====================================
    ==== Start clients -->
      <section class="clients section-padding" data-scroll-index="5">
        <div class="container">
            <!-- section-head -->
          <div class="section-head text-center">
            <h2 data-text="Testimonial"><span>Our Clients</span></h2>
          </div>

          <!-- clients -->
          <div class="owl-carousel owl-theme">
            <div class="items">
              <div class="item text-center">
                <p>" Nulla metus metus ullamcorper vel tincidunt sed vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu ad litora. "</p>
                <div class="img">
                  <img src="<?= base_url('assets/img/')?>team/1.jpg" alt="">
                </div>
                <div class="client-info">
                  <h5>Alex Smith</h5>
                  <h6>Envato Customer</h6>
                </div>
              </div>
            </div>

            <div class="items">
                <div class="item text-center">
                  <p>" Nulla metus metus ullamcorper vel tincidunt sed vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu ad litora. "</p>
                  <div class="img">
                    <img src="<?= base_url('assets/img/')?>team/2.jpg" alt="">
                  </div>
                  <div class="client-info">
                    <h5>Alex Smith</h5>
                    <h6>Envato Customer</h6>
                  </div>
                </div>
              </div>

              <div class="items">
                <div class="item text-center">
                  <p>" Nulla metus metus ullamcorper vel tincidunt sed vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu ad litora. "</p>
                  <div class="img">
                    <img src="<?= base_url('assets/img/')?>team/3.jpg" alt="">
                  </div>
                  <div class="client-info">
                    <h5>Alex Smith</h5>
                    <h6>Envato Customer</h6>
                  </div>
                </div>
              </div>
              <!-- end clients -->
          </div>
        </div>
      </section>
    <!-- =====================================
    ==== end clients -->

