<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <title>Aclema</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta charset="utf-8">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- <bootstrab css> -->
    <link rel="stylesheet" href="<?= base_url('assets/css/')?>bootstrap.min.css">

    <!-- Icon -->
    <link rel="icon" type="image/png" href="img/fav.png">

    <!-- <fonts> -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

      <!-- owel carousel -->
    <link href="<?= base_url('assets/css/')?>owl.theme.default.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css/')?>owl.carousel.min.css" rel="stylesheet">

    <!-- owel fancybox -->
    <link href="<?= base_url('assets/css/')?>jquery.fancybox.min.css" rel="stylesheet">

    <!-- Font Icon Core CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/')?>all.min.css">

    <!-- Style css -->
    <link href="<?= base_url('assets/css/')?>style.css" rel="stylesheet">


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/')?>flip/css/flipdown/flipdown.css">
    <!-- <link rel="stylesheet" type="text/css" href="<?= base_url('assets/')?>flip/css/style.css"> -->
    <script type="text/javascript" src="<?= base_url('assets/')?>flip/js/flipdown/flipdown.js"></script>
    <script type="text/javascript" src="<?= base_url('assets/')?>flip/js/main.js"></script>
</head>

<body>
      


