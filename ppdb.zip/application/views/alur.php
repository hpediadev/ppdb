

    <!-- =====================================
    ==== Start blog -->
      <section class="blog section-padding" data-scroll-index="6">
        <div class="container">
            <!-- section-head -->
          <div class="section-head text-center">
            <h2 data-text="News"><span>Blog</span></h2>
          </div>

          <!-- first row blog -->
          <div class="row items">
            <div class="col-lg-5 info">
              <h6>After Effect</h6>
              <h4>
                <a href="#0">Top 10 Advertisement Templates for After Effects.</a>
              </h4>
              <p>Lorem ipsum dolor, sit amet consectetur amet adipisicing elit. Deleniti, harum amet optio! Nam numquam assum enda minus ex ab autem accusamus ipsam ut asperiores maxime....</p>
              <a class="show" href="#0"> <span>Show More</span> </a>
            </div>

            <div class="col-lg-7 img">
                <img src="<?= base_url('assets/img/')?>news/2.jpg" alt="">
                <span class="date text-center"> 22 <br> JUN</span>
            </div>
          </div>

           <!-- second row blog -->
          <div class="row items sec">
            <div class="col-lg-7 img">
                <img src="<?= base_url('assets/img/')?>news/3.jpg" alt="">
                <span class="date text-center"> 15 <br> FEB</span>
            </div>

            <div class="col-lg-5 info">
              <h6>Wordpress</h6>
              <h4>
                <a href="#0">How Ubiquity Became a Liability for Burberry.</a>
              </h4>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing amet elit. Deleniti, harum optio! amet Nam numquam assum enda minus ex ab autem accusamus ipsam ut asperiores maxime....</p>
              <a class="show" href="#0"> <span>Show More</span> </a>
            </div>
          </div>
        </div>
      </section>
    <!-- =====================================
    ==== end plog -->
      